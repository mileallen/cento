// ─────────────────────────────────────────────────────────────────────────────
// Nota — app.js  (vanilla JS + CodeMirror 5)
// ─────────────────────────────────────────────────────────────────────────────

const DB_NAME = 'nota-db';
const DB_VERSION = 1;
const STORE_NAME = 'handles';
const SESSION_FILE = 'nota-session.json';
const AUTOSAVE_MS = 1500;
const SESSION_MS = 1000;

// ─────────────────────────────────────────────────────────────────────────────
// IndexedDB helpers
// ─────────────────────────────────────────────────────────────────────────────
function openDB() {
    return new Promise( (res, rej) => {
        const r = indexedDB.open(DB_NAME, DB_VERSION);
        r.onupgradeneeded = e => e.target.result.createObjectStore(STORE_NAME);
        r.onsuccess = e => res(e.target.result);
        r.onerror = e => rej(e.target.error);
    }
    );
}
async function dbGet(key) {
    const db = await openDB();
    return new Promise( (res, rej) => {
        const r = db.transaction(STORE_NAME, 'readonly').objectStore(STORE_NAME).get(key);
        r.onsuccess = () => res(r.result);
        r.onerror = () => rej(r.error);
    }
    );
}
async function dbSet(key, val) {
    const db = await openDB();
    return new Promise( (res, rej) => {
        const tx = db.transaction(STORE_NAME, 'readwrite');
        tx.objectStore(STORE_NAME).put(val, key);
        tx.oncomplete = res;
        tx.onerror = () => rej(tx.error);
    }
    );
}

// ─────────────────────────────────────────────────────────────────────────────
// File system helpers
// ─────────────────────────────────────────────────────────────────────────────
async function readFile(fh) {
    return (await fh.getFile()).text();
}
async function writeFile(fh, content) {
    const w = await fh.createWritable();
    await w.write(content);
    await w.close();
}
async function scanDirectory(dirHandle, path='') {
    const nodes = [];
    for await(const [name,handle] of dirHandle.entries()) {
        if (name.startsWith('.') || name === SESSION_FILE)
            continue;
        const nodePath = path ? `${path}/${name}` : name;
        if (handle.kind === 'directory') {
            const children = await scanDirectory(handle, nodePath);
            nodes.push({
                type: 'folder',
                name,
                path: nodePath,
                handle,
                children
            });
        } else if (name.endsWith('.md')) {
            nodes.push({
                type: 'file',
                name,
                path: nodePath,
                handle,
                title: name.replace(/\.md$/, '')
            });
        }
    }
    nodes.sort( (a, b) => {
        if (a.type !== b.type)
            return a.type === 'folder' ? -1 : 1;
        return a.name.localeCompare(b.name);
    }
    );
    return nodes;
}
function findNode(tree, path) {
    for (const n of tree) {
        if (n.path === path)
            return n;
        if (n.type === 'folder' && n.children) {
            const f = findNode(n.children, path);
            if (f)
                return f;
        }
    }
    return null;
}
async function resolveDir(vaultHandle, folderPath) {
    if (!folderPath)
        return vaultHandle;
    let dir = vaultHandle;
    for (const part of folderPath.split('/'))
        dir = await dir.getDirectoryHandle(part);
    return dir;
}
async function uniqueFilename(dirHandle, base='sample') {
    const existing = [];
    for await(const [n] of dirHandle.entries())
        existing.push(n);
    let name = base + '.md'
      , i = 1;
    while (existing.includes(name))
        name = `${base}-${i++}.md`;
    return name;
}
function escHtml(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// ─────────────────────────────────────────────────────────────────────────────
// Markdown → HTML  (preview mode)
// ─────────────────────────────────────────────────────────────────────────────
function mdToHtml(md) {
    const lines = md.split('\n');
    const out = [];
    let inCode = false
      , codeBuf = [];

    for (let i = 0; i < lines.length; i++) {
        const raw = lines[i];
        if (raw.startsWith('```')) {
            if (inCode) {
                out.push(`<pre><code>${escHtml(codeBuf.join('\n'))}</code></pre>`);
                codeBuf = [];
                inCode = false;
            } else {
                inCode = true;
            }
            continue;
        }
        if (inCode) {
            codeBuf.push(raw);
            continue;
        }

        let line = raw.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\*\*\*(.+?)\*\*\*/g, '<strong><em>$1</em></strong>').replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>').replace(/\*(.+?)\*/g, '<em>$1</em>').replace(/_(.+?)_/g, '<em>$1</em>').replace(/`([^`]+)`/g, '<code>$1</code>').replace(/\[\[([^\]]+)\]\]/g, '<a href="#" class="wikilink" data-target="$1">$1</a>').replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank">$1</a>');

        const hm = raw.match(/^(#{1,6})\s(.*)/);
        if (hm) {
            out.push(`<h${hm[1].length}>${line.replace(/^#+\s/, '')}</h${hm[1].length}>`);
            continue;
        }
        if (/^---+$/.test(raw.trim())) {
            out.push('<hr/>');
            continue;
        }
        if (raw.startsWith('> ')) {
            out.push(`<blockquote>${line.slice(2)}</blockquote>`);
            continue;
        }
        if (/^\s*[-*]\s/.test(raw)) {
            out.push(`<li>${line.replace(/^\s*[-*]\s/, '')}</li>`);
            continue;
        }
        if (/^\d+\.\s/.test(raw)) {
            out.push(`<li>${line.replace(/^\d+\.\s/, '')}</li>`);
            continue;
        }
        if (line.trim() === '') {
            out.push('<p></p>');
            continue;
        }
        out.push(`<p>${line}</p>`);
    }
    return out.join('\n').replace(/(<li>.*<\/li>\n?)+/g, m => `<ul>${m}</ul>`);
}

// ─────────────────────────────────────────────────────────────────────────────
// CodeMirror 5 live-preview decorations
// ─────────────────────────────────────────────────────────────────────────────
const HEADING_CLS = ['', 'cm-h1', 'cm-h2', 'cm-h3', 'cm-h4', 'cm-h5', 'cm-h6'];

function rebuildDecorations(cm) {
    cm.operation( () => {
        cm.getAllMarks().forEach(m => m.clear());
        const activeLine = cm.getCursor().line;
        const lineCount = cm.lineCount();
        for (let i = 0; i < lineCount; i++) {
            decorateLine(cm, i, cm.getLine(i), i === activeLine);
        }
    }
    );
}

function decorateLine(cm, lineNo, text, isActive) {
    const mk = (from, to, cls) => cm.markText({
        line: lineNo,
        ch: from
    }, {
        line: lineNo,
        ch: to
    }, {
        className: cls,
        atomic: false
    });

    const hm = text.match(/^(#{1,6}) /);
    if (hm) {
        const level = hm[1].length;
        const prefixLen = level + 1;
        mk(0, prefixLen, isActive ? 'cm-md-syntax' : 'cm-md-hidden');
        mk(prefixLen, text.length, HEADING_CLS[level]);
        return;
    }
    if (text.startsWith('> ')) {
        if (!isActive)
            mk(0, 2, 'cm-md-hidden');
        mk(isActive ? 0 : 2, text.length, 'cm-md-blockquote');
        return;
    }
    if (/^---+$/.test(text.trim())) {
        mk(0, text.length, 'cm-md-syntax');
        return;
    }
    applyInline(cm, lineNo, text, isActive);
}

function applyInline(cm, lineNo, text, isActive) {
    const mk = (from, to, cls) => cm.markText({
        line: lineNo,
        ch: from
    }, {
        line: lineNo,
        ch: to
    }, {
        className: cls,
        atomic: false
    });

    applyPattern(text, /(\*\*\*)(.+?)(\*\*\*)/g, isActive, mk, 'cm-md-syntax', 'cm-md-bold cm-md-italic', 'cm-md-syntax');
    applyPattern(text, /(\*\*)([^*\n]+?)(\*\*)/g, isActive, mk, 'cm-md-syntax', 'cm-md-bold', 'cm-md-syntax');
    applyPattern(text, /(?<!\*)\*(?!\*)([^*\n]+?)\*/g, isActive, mk, 'cm-md-syntax', 'cm-md-italic', 'cm-md-syntax', true);
    applyPattern(text, /(?<!_)_(?!_)([^_\n]+?)_/g, isActive, mk, 'cm-md-syntax', 'cm-md-italic', 'cm-md-syntax', true);
    applyPattern(text, /(`)(.*?)(`)/g, isActive, mk, 'cm-md-syntax', 'cm-md-code', 'cm-md-syntax');

    let m;
    const wikiRe = /\[\[([^\]]+)\]\]/g;
    while ((m = wikiRe.exec(text)) !== null) {
        if (isActive) {
            mk(m.index, m.index + m[0].length, 'cm-md-wikilink');
        } else {
            mk(m.index, m.index + 2, 'cm-md-hidden');
            // [[
            mk(m.index + 2, m.index + 2 + m[1].length, 'cm-md-wikilink');
            // text
            mk(m.index + 2 + m[1].length, m.index + m[0].length, 'cm-md-hidden');
            // ]]
        }
    }

    const linkRe = /\[([^\]]+)\]\(([^)]+)\)/g;
    while ((m = linkRe.exec(text)) !== null) {
        if (isActive) {
            mk(m.index, m.index + m[0].length, 'cm-md-link');
        } else {
            mk(m.index, m.index + 1, 'cm-md-hidden');
            // [
            mk(m.index + 1, m.index + 1 + m[1].length, 'cm-md-link');
            // text
            mk(m.index + 1 + m[1].length, m.index + m[0].length, 'cm-md-hidden');
            // ](href)
        }
    }
}

function applyPattern(text, re, isActive, mk, cls0, cls1, cls2, singleChar=false) {
    let m;
    re.lastIndex = 0;
    while ((m = re.exec(text)) !== null) {
        const full = m[0];
        const start = m.index;
        const content = singleChar ? m[1] : m[2];
        const open = singleChar ? full[0] : m[1];
        const close = singleChar ? full[full.length - 1] : m[3];
        const openLen = open.length;
        const closeLen = close.length;
        const cs = start + openLen;
        const ce = cs + content.length;
        if (isActive) {
            mk(start, cs, cls0);
            mk(cs, ce, cls1);
            mk(ce, ce + closeLen, cls2);
        } else {
            mk(start, cs, 'cm-md-hidden');
            mk(cs, ce, cls1);
            mk(ce, ce + closeLen, 'cm-md-hidden');
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// File tree rendering
// ─────────────────────────────────────────────────────────────────────────────
function renderTree(nodes, app, container) {
    container.innerHTML = '';
    nodes.forEach(node => container.appendChild(makeTreeNode(node, app)));
}

function makeTreeNode(node, app) {
    const div = document.createElement('div');
    div.className = 'tree-node';

    if (node.type === 'folder') {
        const isExpanded = app.expandedFolders.has(node.path);
        const isActive = app.activeFolderPath === node.path;

        const row = document.createElement('div');
        row.className = 'tree-row' + (isActive ? ' active-folder' : '');
        row.innerHTML = `
      <svg class="tree-chevron"><use href="${isExpanded ? '#icon-chevron-down' : '#icon-chevron-right'}"/></svg>
      <svg class="tree-icon tree-folder-icon"><use href="#icon-folder"/></svg>
      <span class="tree-label">${escHtml(node.name)}</span>`;

        row.addEventListener('contextmenu', e => app._showContextMenu(e, node));
        
        row.addEventListener('click', () => {
            if (app.expandedFolders.has(node.path))
                app.expandedFolders.delete(node.path);
            else
                app.expandedFolders.add(node.path);
            app.activeFolderPath = node.path;
            app.renderFileTree();
            app.scheduleSessionSave();
        }
        );
        div.appendChild(row);

        if (isExpanded && node.children.length) {
            const children = document.createElement('div');
            children.className = 'tree-children';
            node.children.forEach(child => children.appendChild(makeTreeNode(child, app)));
            div.appendChild(children);
        }

    } else {
        const activeTab = app.tabs.find(t => t.id === app.activeTabId);
        const isActive = activeTab?.path === node.path;
        const isRenaming = app.renamingPath === node.path;

        const row = document.createElement('div');
        row.className = 'tree-row' + (isActive ? ' active-file' : '');

        if (isRenaming) {
            row.innerHTML = `
        <span style="width:12px;display:inline-block"></span>
        <svg class="tree-icon"><use href="#icon-file"/></svg>`;
            const input = document.createElement('input');
            input.className = 'tree-label-edit';
            input.value = node.title;

            input.addEventListener('keydown', e => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    // Mark as handled so the blur event below does not double-commit.
                    app._renameCommitted = true;
                    app.commitRename(node, input.value);
                }
                if (e.key === 'Escape') {
                    // Mark as handled so blur does not trigger a rename on cancel.
                    app._renameCommitted = true;
                    app.renamingPath = null;
                    app.renderFileTree();
                }
            }
            );
            input.addEventListener('blur', () => {
                // Only fire if Enter / Escape have not already handled this rename session.
                if (!app._renameCommitted) {
                    app.commitRename(node, input.value);
                }
            }
            );

            row.appendChild(input);
            setTimeout( () => {
                input.select();
                input.focus();
            }
            , 30);
        } else {
            row.innerHTML = `
        <span style="width:12px;display:inline-block"></span>
        <svg class="tree-icon"><use href="#icon-file"/></svg>
        <span class="tree-label">${escHtml(node.title)}</span>`;
            row.addEventListener('contextmenu', e => app._showContextMenu(e, node));
            row.addEventListener('click', () => app.openFile(node.handle, node.path, node.title));
        }
        div.appendChild(row);
    }
    return div;
}

// ─────────────────────────────────────────────────────────────────────────────
// App
// ─────────────────────────────────────────────────────────────────────────────
const App = {
    // ── State ──
    vaultHandle: null,
    vaultName: '',
    fileTree: [],
    tabs: [],
    activeTabId: null,
    sidebarView: 'tree',
    editorMode: 'live',
    activeFolderPath: '',
    expandedFolders: new Set(),
    renamingPath: null,
    searchQuery: '',
    searchResults: [],
    searchRan: false,
    saveStatus: '',

    // ── Internals ──
    _editors: {},
    _saveTimers: {},
    _sessionTimer: null,
    _decoTimer: null,
    // Prevents concurrent duplicate opens (e.g. fast double-click on a wikilink)
    _openingPaths: new Set(),
    // Prevents blur from double-committing after Enter/Escape already handled a rename
    _renameCommitted: false,
    _ctxNode: null,

    // ─────────────────────────────────────────────────────────────────────────
    // Boot
    // ─────────────────────────────────────────────────────────────────────────
    init() {
        document.getElementById('btn-open-vault').addEventListener('click', () => this.openVault());
        document.getElementById('btn-open-vault-welcome').addEventListener('click', () => this.openVault());
        document.getElementById('btn-new-file').addEventListener('click', () => this.newFile());
        document.getElementById('btn-sidebar-tree').addEventListener('click', () => this.setSidebarView('tree'));
        document.getElementById('btn-sidebar-search').addEventListener('click', () => {
            this.setSidebarView('search');
            document.getElementById('search-input').focus();
        }
        );
        document.getElementById('btn-toggle-preview').addEventListener('click', () => this.toggleEditorMode());
        document.getElementById('btn-save').addEventListener('click', () => this.saveActiveNote());
        document.getElementById('btn-search-go').addEventListener('click', () => this.runSearch());

        const searchInput = document.getElementById('search-input');
        searchInput.addEventListener('keydown', e => {
            if (e.key === 'Enter')
                this.runSearch();
        }
        );
        searchInput.addEventListener('input', e => {
            this.searchQuery = e.target.value;
        }
        );

        window.addEventListener('keydown', e => {
            if ((e.ctrlKey || e.metaKey) && e.key === 's') {
                e.preventDefault();
                this.saveActiveNote();
            }
        }
        );

        // Wikilink / standard-link clicks inside editor panes
        document.getElementById('panes-container').addEventListener('click', e => {
            const el = e.target.closest('.cm-md-link, .cm-md-wikilink');
            if (!el)
                return;
            e.preventDefault();
            const isWiki = el.classList.contains('cm-md-wikilink');
            const cm = this._editors[this.activeTabId];
            if (!cm)
                return;
            const pos = cm.coordsChar({
                left: e.clientX,
                top: e.clientY
            });
            const line = cm.getLine(pos.line) || '';
            if (isWiki) {
                const m = line.match(/\[\[([^\]]+)\]\]/);
                if (m)
                    this.handleLinkClick({
                        href: m[1],
                        isWiki: true
                    });
            } else {
                const m = line.match(/\[([^\]]+)\]\(([^)]+)\)/);
                if (m)
                    this.handleLinkClick({
                        href: m[2],
                        isWiki: false
                    });
            }
        }
        );

        // Context menu actions
    document.getElementById('ctx-rename').addEventListener('click', () => {
      const node = this._ctxNode;
      this._hideContextMenu();
      if (!node) return;
      this._renameCommitted = false;
      this.renamingPath = node.path;
      this.renderFileTree();
    });
    document.getElementById('ctx-delete').addEventListener('click', () => {
      const node = this._ctxNode;
      this._hideContextMenu();
      if (!node) return;
      this.deleteNode(node);
    });

    // Dismiss context menu on click or scroll anywhere
    document.addEventListener('click',    () => this._hideContextMenu());
    document.addEventListener('scroll',   () => this._hideContextMenu(), true);
    document.addEventListener('keydown',  e => { if (e.key === 'Escape') this._hideContextMenu(); });

        // Initial render
        this._renderToolbar();
        this._renderTabsBar();
        this._renderSidebar();

        // Restore previous vault
        (async () => {
            try {
                const handle = await dbGet('vaultHandle');
                if (handle) {
                    const perm = await handle.requestPermission({
                        mode: 'readwrite'
                    });
                    if (perm === 'granted')
                        await this.mountVault(handle);
                }
            } catch {}
        }
        )();
    },

    // ─────────────────────────────────────────────────────────────────────────
    // UI renderers — each updates only its own slice of the DOM
    // ─────────────────────────────────────────────────────────────────────────
    _renderToolbar() {
        const vaultEl = document.getElementById('vault-name');
        if (this.vaultName) {
            vaultEl.textContent = this.vaultName;
            vaultEl.style.display = '';
        } else {
            vaultEl.style.display = 'none';
        }
        document.getElementById('btn-new-file').disabled = !this.vaultHandle;
        document.getElementById('sidebar-vault-name').textContent = this.vaultName || 'No Vault';
        document.getElementById('no-vault-msg').style.display = this.vaultHandle ? 'none' : '';
    },

    _renderTabsBar() {
        const tabsBar = document.getElementById('tabs-bar');
        const welcome = document.getElementById('welcome');
        const hasTab = this.tabs.length > 0;

        tabsBar.style.display = hasTab ? '' : 'none';
        welcome.style.display = hasTab ? 'none' : '';

        // Rebuild tab strip
        tabsBar.innerHTML = '';
        for (const tab of this.tabs) {
            const div = document.createElement('div');
            div.className = 'tab' + (tab.id === this.activeTabId ? ' active' : '');
            div.innerHTML = `
        <span class="tab-title">${escHtml(tab.title)}${tab.dirty ? ' ●' : ''}</span>
        <span class="tab-close"><svg><use href="#icon-x"/></svg></span>`;
            div.addEventListener('click', () => this.activateTab(tab.id));
            div.querySelector('.tab-close').addEventListener('click', e => {
                e.stopPropagation();
                this.closeTab(tab.id);
            }
            );
            tabsBar.appendChild(div);
        }

        // Toolbar buttons that only appear when a tab is open
        const hasActive = !!this.activeTabId;
        const btnPreview = document.getElementById('btn-toggle-preview');
        const btnSave = document.getElementById('btn-save');
        btnPreview.style.display = hasActive ? '' : 'none';
        btnSave.style.display = hasActive ? '' : 'none';

        if (hasActive) {
            const isPreview = this.editorMode === 'preview';
            btnPreview.classList.toggle('active', isPreview);
            btnPreview.dataset.tip = isPreview ? 'Live Preview' : 'Preview Mode';
            btnPreview.querySelector('.svg-eye').style.display = isPreview ? 'none' : '';
            btnPreview.querySelector('.svg-edit').style.display = isPreview ? '' : 'none';
        }
    },

    _renderSaveStatus() {
        const el = document.getElementById('save-indicator');
        el.className = this.saveStatus;
        el.textContent = this.saveStatus === 'saving' ? 'saving…' : this.saveStatus === 'saved' ? 'saved' : '';
    },

    _renderSidebar() {
        const isTree = this.sidebarView === 'tree';
        document.getElementById('panel-tree').style.display = isTree ? '' : 'none';
        document.getElementById('panel-search').style.display = isTree ? 'none' : '';
        document.getElementById('btn-sidebar-tree').classList.toggle('active', isTree);
        document.getElementById('btn-sidebar-search').classList.toggle('active', !isTree);
    },

    _renderSearchResults() {
        const list = document.getElementById('search-results-list');
        const empty = document.getElementById('search-empty');
        list.innerHTML = '';
        empty.style.display = (this.searchRan && this.searchResults.length === 0) ? '' : 'none';
        for (const r of this.searchResults) {
            const div = document.createElement('div');
            div.className = 'search-result-item';
            div.innerHTML = `
        <div class="search-result-title">${escHtml(r.title)}</div>
        <div class="search-result-context">${r.context}</div>`;
            div.addEventListener('click', () => this.openFile(r.handle, r.path, r.title));
            list.appendChild(div);
        }
    },

    // ─────────────────────────────────────────────────────────────────────────
    // Sidebar
    // ─────────────────────────────────────────────────────────────────────────
    setSidebarView(view) {
        this.sidebarView = view;
        this._renderSidebar();
        this.scheduleSessionSave();
    },

    // ─────────────────────────────────────────────────────────────────────────
    // Vault
    // ─────────────────────────────────────────────────────────────────────────
    async openVault() {
        try {
            const handle = await window.showDirectoryPicker({
                mode: 'readwrite'
            });
            await dbSet('vaultHandle', handle);
            await this.mountVault(handle);
        } catch (e) {
            if (e.name !== 'AbortError')
                this.toast('Could not open folder: ' + e.message);
        }
    },

    async mountVault(handle) {
        this.vaultHandle = handle;
        this.vaultName = handle.name;
        this.activeFolderPath = '';
        this._renderToolbar();
        await this.refreshTree();
        await this.restoreSession();
    },

    async refreshTree() {
        if (!this.vaultHandle)
            return;
        this.fileTree = await scanDirectory(this.vaultHandle);
        this.renderFileTree();
    },

    renderFileTree() {
        const root = document.getElementById('file-tree-root');
        if (root)
            renderTree(this.fileTree, this, root);
    },

    // ─────────────────────────────────────────────────────────────────────────
    // Session persistence
    // ─────────────────────────────────────────────────────────────────────────
    async saveSession() {
        if (!this.vaultHandle)
            return;
        const session = {
            activeTabId: this.activeTabId,
            editorMode: this.editorMode,
            sidebarView: this.sidebarView,
            activeFolderPath: this.activeFolderPath,
            expandedFolders: [...this.expandedFolders],
            tabs: this.tabs.map(t => ({
                id: t.id,
                title: t.title,
                path: t.path,
                scrollTop: this._editors[t.id]?.getScrollInfo().top ?? t.scrollTop ?? 0,
                cursorPos: this._editors[t.id] ? ( () => {
                    const c = this._editors[t.id].getCursor();
                    return {
                        line: c.line,
                        ch: c.ch
                    };
                }
                )() : (t.cursorPos || {
                    line: 0,
                    ch: 0
                }),
            })),
        };
        try {
            const fh = await this.vaultHandle.getFileHandle(SESSION_FILE, {
                create: true
            });
            await writeFile(fh, JSON.stringify(session, null, 2));
        } catch {}
    },

    scheduleSessionSave() {
        clearTimeout(this._sessionTimer);
        this._sessionTimer = setTimeout( () => this.saveSession(), SESSION_MS);
    },

    async restoreSession() {
        try {
            const fh = await this.vaultHandle.getFileHandle(SESSION_FILE);
            const text = await readFile(fh);
            const s = JSON.parse(text);

            this.editorMode = s.editorMode || 'live';
            this.sidebarView = s.sidebarView || 'tree';
            this.activeFolderPath = s.activeFolderPath || '';
            this.expandedFolders = new Set(s.expandedFolders || []);
            this._renderSidebar();

            if (s.tabs?.length) {
                for (const t of s.tabs) {
                    const node = findNode(this.fileTree, t.path);
                    if (node?.type === 'file') {
                        await this.openFile(node.handle, node.path, node.title, t.cursorPos, t.scrollTop, t.id);
                    }
                }
                if (s.activeTabId)
                    this.activateTab(s.activeTabId);
            }
        } catch {/* no session yet — fine */
        }
    },

    // ─────────────────────────────────────────────────────────────────────────
    // Files / tabs
    // ─────────────────────────────────────────────────────────────────────────
    async openFile(fileHandle, path, title, cursorPos={
        line: 0,
        ch: 0
    }, scrollTop=0, tabId=null) {
        // Guard 1: tab is already open — just switch to it
        const existing = this.tabs.find(t => t.path === path);
        if (existing) {
            this.activateTab(existing.id);
            return;
        }

        // Guard 2: concurrent open of same path (fast double-click on a wikilink)
        if (this._openingPaths.has(path))
            return;
        this._openingPaths.add(path);

        try {
            const content = await readFile(fileHandle);
            const id = tabId || ('tab-' + Date.now() + '-' + Math.random().toString(36).slice(2));
            this.tabs.push({
                id,
                title,
                path,
                handle: fileHandle,
                dirty: false,
                scrollTop,
                cursorPos
            });
            this.activeTabId = id;
            this._renderTabsBar();

            // Wait one tick for the tab bar DOM to settle before mounting CodeMirror
            await new Promise(r => setTimeout(r, 0));
            this.mountEditor(id, content, cursorPos, scrollTop);
            this.renderFileTree();
            this.scheduleSessionSave();
        } finally {
            this._openingPaths.delete(path);
        }
    },

    activateTab(id) {
        // Snapshot scroll of the pane we're leaving
        const prevCm = this._editors[this.activeTabId];
        if (prevCm) {
            const prevTab = this.tabs.find(t => t.id === this.activeTabId);
            if (prevTab)
                prevTab.scrollTop = prevCm.getScrollInfo().top;
        }

        this.activeTabId = id;

        // Show the correct pane for this tab, respecting the current global editorMode
        document.querySelectorAll('.editor-pane, .preview-only-pane').forEach(p => {
            p.classList.remove('active');
        }
        );

        if (this.editorMode === 'preview') {
            // Ensure a preview pane exists for this tab
            let preview = document.querySelector(`.preview-only-pane[data-tab-id="${id}"]`);
            if (!preview) {
                const cm = this._editors[id];
                preview = document.createElement('div');
                preview.className = 'preview-only-pane';
                preview.dataset.tabId = id;
                preview.innerHTML = `<div class="preview-content">${mdToHtml(cm.getValue())}</div>`;
                preview.addEventListener('click', e => {
                    const a = e.target.closest('a');
                    if (!a)
                        return;
                    e.preventDefault();
                    if (a.classList.contains('wikilink')) {
                        this.handleLinkClick({
                            href: a.dataset.target,
                            isWiki: true
                        });
                    } else {
                        window.open(a.href, '_blank');
                    }
                }
                );
                document.getElementById('panes-container').appendChild(preview);
            }
            preview.classList.add('active');
        } else {
            document.querySelector(`.editor-pane[data-tab-id="${id}"]`)?.classList.add('active');
        }

        const cm = this._editors[id];
        if (cm) {
            // Calling cm.refresh() while a pane is still display:none corrupts
            // CodeMirror's internal display.view array, causing a crash the next
            // time anything tries to click into the editor.
            // requestAnimationFrame ensures the browser has painted the pane first.
            requestAnimationFrame( () => {
                const tab = this.tabs.find(t => t.id === id);
                if (tab)
                    cm.scrollTo(null, tab.scrollTop || 0);
                cm.refresh();
                cm.focus();
                if (this.editorMode === 'live')
                    rebuildDecorations(cm);
            }
            );
        }

        this._renderTabsBar();
        this.renderFileTree();
        this.scheduleSessionSave();
    },

    async closeTab(id) {
        const tab = this.tabs.find(t => t.id === id);
        if (!tab)
            return;
        if (tab.dirty && !confirm(`"${tab.title}" has unsaved changes. Close anyway?`))
            return;

        if (this._editors[id]) {
            this._editors[id].toTextArea();
            delete this._editors[id];
        }
        document.querySelector(`[data-tab-id="${id}"]`)?.remove();

        const idx = this.tabs.findIndex(t => t.id === id);
        this.tabs.splice(idx, 1);

        if (this.activeTabId === id) {
            const next = this.tabs[Math.min(idx, this.tabs.length - 1)];
            this.activeTabId = next?.id || null;
            if (this.activeTabId)
                this.activateTab(this.activeTabId);
        }

        this._renderTabsBar();
        this.renderFileTree();
        this.scheduleSessionSave();
    },

    // ─────────────────────────────────────────────────────────────────────────
    // Mount CodeMirror
    // ─────────────────────────────────────────────────────────────────────────
    mountEditor(tabId, content, cursorPos={
        line: 0,
        ch: 0
    }, scrollTop=0) {
        const container = document.getElementById('panes-container');

        const pane = document.createElement('div');
        pane.className = 'editor-pane active';
        pane.dataset.tabId = tabId;
        container.appendChild(pane);

        // Immediately hide all other panes
        container.querySelectorAll('.editor-pane, .preview-only-pane').forEach(p => {
            if (p !== pane)
                p.classList.remove('active');
        }
        );

        const ta = document.createElement('textarea');
        pane.appendChild(ta);

        const cm = CodeMirror.fromTextArea(ta, {
            mode: 'markdown',
            lineWrapping: true,
            autofocus: true,
            styleActiveLine: true,
            extraKeys: {
                'Ctrl-S': () => this.saveActiveNote(),
                'Cmd-S': () => this.saveActiveNote(),
            },
        });

        cm.setValue(content);
        cm.setCursor(cursorPos);
        cm.setSize('100%', '100%');
        this._editors[tabId] = cm;

        if (this.editorMode === 'live')
            rebuildDecorations(cm);

        const onCursorOrChange = () => {
            if (this.editorMode !== 'live')
                return;
            clearTimeout(this._decoTimer);
            this._decoTimer = setTimeout( () => rebuildDecorations(cm), 50);
        }
        ;
        cm.on('cursorActivity', onCursorOrChange);
        cm.on('change', (_, change) => {
            onCursorOrChange();
            const tab = this.tabs.find(t => t.id === tabId);
            if (tab && change.origin !== 'setValue') {
                tab.dirty = true;
                this._renderTabsBar();
                this.scheduleAutoSave(tabId);
            }
        }
        );

        requestAnimationFrame( () => {
            cm.scrollTo(null, scrollTop);
            cm.refresh();
            if (this.editorMode === 'preview')
                this.activateTab(tabId);
        }
        );

    },

    // ─────────────────────────────────────────────────────────────────────────
    // Editor mode  (live ↔ preview)
    // ─────────────────────────────────────────────────────────────────────────
    toggleEditorMode() {
        this.editorMode = this.editorMode === 'live' ? 'preview' : 'live';

        if (this.editorMode === 'preview') {
            const tabId = this.activeTabId;
            const cm = this._editors[tabId];
            if (!cm)
                return;
                  // Save CM scroll position before switching
      const tab = this.tabs.find(t => t.id === tabId);
      if (tab) tab.scrollTop = cm.getScrollInfo().top;

            document.querySelector(`.editor-pane[data-tab-id="${tabId}"]`)?.classList.remove('active');
            document.querySelector(`.preview-only-pane[data-tab-id="${tabId}"]`)?.remove();

            const preview = document.createElement('div');
            preview.className = 'preview-only-pane active';
            preview.dataset.tabId = tabId;
            preview.innerHTML = `<div class="preview-content">${mdToHtml(cm.getValue())}</div>`;
            preview.addEventListener('click', e => {
                const a = e.target.closest('a');
                if (!a)
                    return;
                e.preventDefault();
                if (a.classList.contains('wikilink')) {
                    this.handleLinkClick({
                        href: a.dataset.target,
                        isWiki: true
                    });
                } else {
                    window.open(a.href, '_blank');
                }
            }
            );
            document.getElementById('panes-container').appendChild(preview);
      if (tab) preview.scrollTop = tab.scrollTop || 0;

        } else {
            document.querySelectorAll('.preview-only-pane').forEach(p => p.remove());
            const tabId = this.activeTabId;
            document.querySelector(`.editor-pane[data-tab-id="${tabId}"]`)?.classList.add('active');
            const cm = this._editors[tabId];
            if (cm) {
                requestAnimationFrame( () => {
                    cm.refresh();
                    cm.focus();
                    rebuildDecorations(cm);
                }
                );
            }
        }

        this._renderTabsBar();
        // refreshes the preview toggle button state
        this.scheduleSessionSave();
    },

    // ─────────────────────────────────────────────────────────────────────────
    // Save
    // ─────────────────────────────────────────────────────────────────────────
    scheduleAutoSave(tabId) {
        clearTimeout(this._saveTimers[tabId]);
        this._saveTimers[tabId] = setTimeout( () => this.saveTab(tabId), AUTOSAVE_MS);
    },

    async saveActiveNote() {
        if (this.activeTabId)
            await this.saveTab(this.activeTabId);
    },

    async saveTab(tabId) {
        const tab = this.tabs.find(t => t.id === tabId);
        const cm = this._editors[tabId];
        if (!tab || !cm)
            return;

        this.saveStatus = 'saving';
        this._renderSaveStatus();
        try {
            await writeFile(tab.handle, cm.getValue());
            tab.dirty = false;
            this.saveStatus = 'saved';
            this._renderSaveStatus();
            this._renderTabsBar();
            setTimeout( () => {
                if (this.saveStatus === 'saved') {
                    this.saveStatus = '';
                    this._renderSaveStatus();
                }
            }
            , 2000);
            this.scheduleSessionSave();
        } catch (e) {
            this.saveStatus = '';
            this._renderSaveStatus();
            this.toast('Save failed: ' + e.message);
        }
    },

    // ─────────────────────────────────────────────────────────────────────────
    // New file
    // ─────────────────────────────────────────────────────────────────────────
    async newFile() {
        if (!this.vaultHandle)
            return;
        let dirHandle;
        try {
            dirHandle = this.activeFolderPath ? await resolveDir(this.vaultHandle, this.activeFolderPath) : this.vaultHandle;
        } catch {
            dirHandle = this.vaultHandle;
        }

        const filename = await uniqueFilename(dirHandle, 'sample');
        const fh = await dirHandle.getFileHandle(filename, {
            create: true
        });
        await writeFile(fh, '');

        const path = this.activeFolderPath ? `${this.activeFolderPath}/${filename}` : filename;
        const title = filename.replace(/\.md$/, '');

        await this.refreshTree();
        await this.openFile(fh, path, title);

        // Begin inline rename — reset the guard flag fresh for this session
        await new Promise(r => setTimeout(r, 50));
        this._renameCommitted = false;
        this.renamingPath = path;
        this.renderFileTree();
    },

    // ─────────────────────────────────────────────────────────────────────────
    // Rename
    // ─────────────────────────────────────────────────────────────────────────
    async commitRename(node, newTitle) {
        this.renamingPath = null;
        if (!newTitle?.trim()) {
            this.renderFileTree();
            return;
        }

        const newName = newTitle.trim().replace(/\.md$/, '') + '.md';
        if (newName === node.name) {
            this.renderFileTree();
            return;
        }

        const parentPath = node.path.includes('/') ? node.path.substring(0, node.path.lastIndexOf('/')) : '';

        try {
            const dirHandle = parentPath ? await resolveDir(this.vaultHandle, parentPath) : this.vaultHandle;

            // Collision check
            try {
                await dirHandle.getFileHandle(newName);
                this.toast('A file with that name already exists.');
                this.renderFileTree();
                return;
            } catch {}

            const content = await readFile(node.handle);
            const newFh = await dirHandle.getFileHandle(newName, {
                create: true
            });
            await writeFile(newFh, content);
            await dirHandle.removeEntry(node.name);

            // Update the open tab if this file is currently open
            const tab = this.tabs.find(t => t.path === node.path);
            if (tab) {
                const newPath = parentPath ? `${parentPath}/${newName}` : newName;
                tab.title = newName.replace(/\.md$/, '');
                tab.path = newPath;
                tab.handle = newFh;
            }

            await this.refreshTree();
            this._renderTabsBar();
            this.scheduleSessionSave();
        } catch (e) {
            this.toast('Rename failed: ' + e.message);
            this.renderFileTree();
        }
    },

    // ─────────────────────────────────────────────────────────────────────────
    // Search
    // ─────────────────────────────────────────────────────────────────────────
    async runSearch() {
        if (!this.vaultHandle || !this.searchQuery.trim())
            return;
        this.searchResults = [];
        this.searchRan = true;
        await this._searchNodes(this.fileTree, this.searchQuery.toLowerCase());
        this._renderSearchResults();
    },

    async _searchNodes(nodes, query) {
        for (const node of nodes) {
            if (node.type === 'folder' && node.children) {
                await this._searchNodes(node.children, query);
            } else if (node.type === 'file') {
                try {
                    const text = await readFile(node.handle);
                    const lines = text.split('\n');
                    const idx = lines.findIndex(l => l.toLowerCase().includes(query));
                    if (idx === -1)
                        continue;
                    const ctx = lines.slice(Math.max(0, idx - 1), Math.min(lines.length, idx + 2)).join('\n');
                    const highlighted = escHtml(ctx).replace(new RegExp(escHtml(query),'gi'), m => `<mark>${m}</mark>`);
                    this.searchResults.push({
                        path: node.path,
                        handle: node.handle,
                        title: node.title,
                        context: highlighted,
                    });
                } catch {}
            }
        }
    },

    // ─────────────────────────────────────────────────────────────────────────
    // Link navigation
    // ─────────────────────────────────────────────────────────────────────────
    async handleLinkClick({href, isWiki}) {
        if (!this.vaultHandle)
            return;
        if (isWiki) {
            const match = this._findNoteByTitle(this.fileTree, href);
            if (match)
                await this.openFile(match.handle, match.path, match.title);
            else
                this.toast(`Note not found: [[${href}]]`);
        } else {
            if (/^https?:\/\//.test(href)) {
                window.open(href, '_blank');
                return;
            }
            const node = findNode(this.fileTree, href);
            if (node)
                await this.openFile(node.handle, node.path, node.title);
            else
                this.toast(`Note not found: ${href}`);
        }
    },

    _findNoteByTitle(nodes, title) {
        for (const n of nodes) {
            if (n.type === 'file' && n.title.toLowerCase() === title.toLowerCase())
                return n;
            if (n.type === 'folder' && n.children) {
                const f = this._findNoteByTitle(n.children, title);
                if (f)
                    return f;
            }
        }
        return null;
    },

    // ─────────────────────────────────────────────────────────────────────────
    // Toast
    // ─────────────────────────────────────────────────────────────────────────
    toast(msg, duration=3000) {
        const el = document.getElementById('toast');
        el.textContent = msg;
        el.classList.add('show');
        setTimeout( () => el.classList.remove('show'), duration);
    },

    _showContextMenu(e, node) {
    e.preventDefault();
    this._ctxNode = node;
    const menu = document.getElementById('context-menu');
    document.getElementById('ctx-rename').style.display = node.type === 'folder' ? 'none' : '';
    menu.classList.add('show');
    const x = Math.min(e.clientX, window.innerWidth  - menu.offsetWidth  - 8);
    const y = Math.min(e.clientY, window.innerHeight - menu.offsetHeight - 8);
    menu.style.left = x + 'px';
    menu.style.top  = y + 'px';
  },

  _hideContextMenu() {
    document.getElementById('context-menu').classList.remove('show');
    this._ctxNode = null;
  },

  async deleteNode(node) {
    const label = node.type === 'folder' ? `folder "${node.name}" and all its contents` : `"${node.name}"`;
    if (!confirm(`Permanently delete ${label}?`)) return;

    const parentPath = node.path.includes('/')
      ? node.path.substring(0, node.path.lastIndexOf('/'))
      : '';

    try {
      const dirHandle = parentPath
        ? await resolveDir(this.vaultHandle, parentPath)
        : this.vaultHandle;
      await dirHandle.removeEntry(node.name, { recursive: true });

      // Close any open tabs that were inside this node
      const pathPrefix = node.type === 'folder' ? node.path + '/' : null;
      const toClose = this.tabs.filter(t =>
        t.path === node.path || (pathPrefix && t.path.startsWith(pathPrefix)));
      for (const tab of toClose) await this.closeTab(tab.id);

      await this.refreshTree();
      this.scheduleSessionSave();
    } catch (e) {
      this.toast('Delete failed: ' + e.message);
    }
  },

};

App.init();
